#!/bin/bash
mkdir -p find_here/dir1 
mkdir -p find_here/dir2 
mkdir -p find_here/dir1/subdir
mkdir -p find_here/dir3

touch find_here/dir3/{foo,moo}np{1,2}.txt
touch find_here/dir1/foo{1..4}{a..d}.txt 
touch find_here/dir2/milk{2,3,4,5,moo,foo}.txt
touch find_here/dir1/subdir/abc{koo}{1,2,3}.txt
touch find_here/moo{1..4}{a..f}.txt
