#!/bin/bash

rm -rf find_here
